package com.tg.codingtest.preferenceretriever;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PreferenceRetrieverApplicationTests {

	@Test
	void contextLoads() {
	}

}
