package com.tg.codingtest.preferencecreator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PreferenceCreatorApplication {

	public static void main(String[] args) {
		SpringApplication.run(PreferenceCreatorApplication.class, args);
	}

}
